$(document).ready(function () {


});

$(window).load(function () {

    $(".loader_inner").fadeOut();
    //$(".loader").delay(400).fadeOut("toggle");
    //
    //$(".top_text h1").animated("fadeInDown", "fadeOutUp");
    //$(".top_text p").animated("fadeInUp", "fadeOutDown");

});

