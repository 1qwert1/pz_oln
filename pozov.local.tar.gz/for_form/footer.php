

<div class="modal-footer"><a href="http://pozov.online">pozov.online</a></div>

</div>



<!--    <script src="libs/html5shiv/es5-shim.min.js"></script>-->
<!--    <script src="libs/html5shiv/html5shiv.min.js"></script>-->
<!--    <script src="libs/html5shiv/html5shiv-printshiv.min.js"></script>-->
<!--    <script src="libs/respond/respond.min.js"></script>-->

<!--    <script src="libs/animate/animate-css.js"></script>-->
<!--    <script src="libs/jqBootstrapValidation/jqBootstrapValidation.js"></script>-->

<script src="../js/common.js"></script>

<!-- Yandex.Metrika counter --><!-- /Yandex.Metrika counter -->
<!-- Google Analytics counter --><!-- /Google Analytics counter -->
<!-- Yandex.Metrika counter -->
<script type="text/javascript">
    (function (d, w, c) {
        (w[c] = w[c] || []).push(function() {
            try {
                w.yaCounter35886050 = new Ya.Metrika({
                    id:35886050,
                    clickmap:true,
                    trackLinks:true,
                    accurateTrackBounce:true
                });
            } catch(e) { }
        });

        var n = d.getElementsByTagName("script")[0],
            s = d.createElement("script"),
            f = function () { n.parentNode.insertBefore(s, n); };
        s.type = "text/javascript";
        s.async = true;
        s.src = "https://mc.yandex.ru/metrika/watch.js";

        if (w.opera == "[object Opera]") {
            d.addEventListener("DOMContentLoaded", f, false);
        } else { f(); }
    })(document, window, "yandex_metrika_callbacks");
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/35886050" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
</body>
</html>