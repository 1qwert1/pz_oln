
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <!--                <meta http-equiv="refresh" content="1">-->
    <title>Позов онлайн</title>
    <meta name="description" content="подготовка юридических документов онлайн"/>
    <meta name="keywords" content="договора, иски, заявления">
    <meta name="author" content="IPC2B llc">
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <script src="../css/modernizer.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <link rel="stylesheet" type="text/css" href="../libs/bootstrap/bootstrap.css"/>
    <link rel="stylesheet" href="../js/jquery-ui.css">
    <link rel="stylesheet" type="text/css" href="../css/media.css"/>
    <link rel="stylesheet" type="text/css" href="../css/fonts.css"/>
    <link rel="stylesheet" type="text/css" href="../css/main-next.css"/>
    <script src="../libs/jquery/jquery-2.1.3.min.js"></script>
    <script src="../js/jquery-ui.js"></script>
    <script>
        (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
                (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
            m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
        })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

        ga('create', 'UA-54699426-3', 'auto');
        ga('send', 'pageview');

    </script>


</head>
<body>


<div class="container">


    <div class="modal-header"><h3><?php if($val_){echo 'Формування ' .$val_;} ?></h3></div>



    <br>
    <br>