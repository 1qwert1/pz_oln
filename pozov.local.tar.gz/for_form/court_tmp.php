<!--для суда временный файл без возможности выбора-->

<br>
<h4>Введіть назву суду</h4>
<div class="form-group">

    <textarea required type="text" class="form-control" placeholder="Франківський районний суд м. Львова"
              name="court"></textarea>
</div>
<br>
<h4>Введіть адресу суду</h4>
<div class="form-group">

    <input required type="text" class="form-control" placeholder="м.Львів, вул.І.Франка, 55"
           name="address_court">
</div>