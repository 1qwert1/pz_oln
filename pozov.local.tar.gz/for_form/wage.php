
<!--для иска по зарплате-->


<br>
<h4>Дата прийняття на роботу</h4>
<div class="form-group">

    <input type="text" class="form-control datepicker"
           name="firstDayWork">

</div>


<br>
<h4>Дата звільнення з роботи</h4>
<div class="form-group">

    <input type="text" class="form-control datepicker"
           name="andWork">

</div>

<br>
<h4>Сума заборгованості на дату звільнення</h4>
<div class="form-group">

    <input required type="text" class="form-control" pattern="[0-9.]*" placeholder="10000.00"
           name="place_marrige">

</div>

