<?php
if ($_POST):

    $val = $_POST['value'];


    ?>

    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
<!--                <meta http-equiv="refresh" content="1">-->
        <title>Позов онлайн</title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
        <link rel="stylesheet" href="libs/bootstrap/bootstrap.css"/>
        <link rel="stylesheet" href="css/media.css"/>
        <link rel="stylesheet" href="css/fonts.css"/>
        <link rel="stylesheet" href="css/main-next.css"/>


    </head>
    <body>


    <div class="container">
        <div class="modal-header"><h1>Форма для формування <?php echo $val; ?></h1></div>
        <br>
        <br>
        <form action="list.php" method="post">
            <h4>Ваше им'я в родовому відміннику</h4>
            <div class="input-group">
                <span class="input-group-addon"></span>
                <input type="text" class="form-control" placeholder="Петренко Семен Васильович"
                       aria-describedby="sizing-addon1" name="name">
            </div>

            <br>
            <h4>Ваша адреса</h4>
            <div class="input-group">
                <span class="input-group-addon"></span>
                <input type="text" class="form-control" placeholder="03035, м.Київ, вул.Артема, 22"
                       aria-describedby="sizing-addon1" name="adress">
            </div>
            <h4>Оберіть регіон суду</h4>
            <div class="input-group"><span class="input-group-addon"></span>
            <div class="form-group">
                <!--                <label for="sel1">Select list:</label>-->
                <select class="form-control" id="sel1">
                    <option value="2">Автономна Республіка Крим</option>
                    <option value="3">Вінницька область</option>
                    <option value="4">Волинська область</option>
                    <option value="5">Дніпропетровська область</option>
                    <option value="6">Донецька область</option>
                    <option value="7">Житомирська область</option>
                    <option value="8">Закарпатська область</option>
                    <option value="9">Запорізька область</option>
                    <option value="10">Івано-Франківська область</option>
                    <option value="11">Київська область</option>
                    <option value="12">Кіровоградська область</option>
                    <option value="13">Луганська область</option>
                    <option value="14">Львівська область</option>
                    <option value="15">Миколаївська область</option>
                    <option value="16">Одеська область</option>
                    <option value="17">Полтавська область</option>
                    <option value="18">Рівненська область</option>
                    <option value="19">Сумська область</option>
                    <option value="20">Тернопільська область</option>
                    <option value="21">Харківська область</option>
                    <option value="22">Херсонська область</option>
                    <option value="23">Хмельницька область</option>
                    <option value="24">Черкаська область</option>
                    <option value="25">Чернівецька область</option>
                    <option value="26">Чернігівська область</option>
                    <option value="27">м. Київ</option>
                    <option value="28">м. Севастополь</option>
                    <option value="29">ВС Центральний регіон</option>
                    <option value="30">ВС Західний регіон</option>
                    <option value="31">ВС Південний регіон</option>
                    <option value="32">ВС ВМС України</option>
                </select>
            </div></div>


        </form>


    </div>


    <!--</div>-->


    <!--<div class="hidden"></div>-->


    <script src="libs/jquery/jquery-2.1.3.min.js"></script>

<!--    <script src="libs/html5shiv/es5-shim.min.js"></script>-->
<!--    <script src="libs/html5shiv/html5shiv.min.js"></script>-->
<!--    <script src="libs/html5shiv/html5shiv-printshiv.min.js"></script>-->
<!--    <script src="libs/respond/respond.min.js"></script>-->

<!--    <script src="libs/animate/animate-css.js"></script>-->
<!--    <script src="libs/jqBootstrapValidation/jqBootstrapValidation.js"></script>-->

    <script src="js/common.js"></script>

    <!-- Yandex.Metrika counter --><!-- /Yandex.Metrika counter -->
    <!-- Google Analytics counter --><!-- /Google Analytics counter -->
    </body>
    </html>


<?php
endif;
?>