insert into `Courts`(id, `date`, name) values (2,'2016-02.02', 'bob');
# DELETE FROM Courts WHERE id=2;
# DELETE FROM Courts WHERE id=1;
